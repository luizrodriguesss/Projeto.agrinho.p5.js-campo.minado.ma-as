let cols;
let rows;
let cellSize = 40; // Tamanho de cada célula do tabuleiro
let grid; // O grid do jogo
let totalApples = 10; // Número de maçãs podres (bombas)
let gameover = false;
let revealedCount = 0; // Contagem de células reveladas sem maçã

// Classe para cada célula do tabuleiro
class Cell {
    constructor(i, j) {
        this.i = i;
        this.j = j;
        this.x = i * cellSize;
        this.y = j * cellSize;
        this.hasApple = false; // Se tem uma maçã podre
        this.revealed = false; // Se a célula foi revelada
        this.flagged = false; // Se a célula está "bandeirada"
        this.neighborAppleCount = 0; // Quantidade de maçãs vizinhas
    }

    // Exibe a célula
    show() {
        stroke(0);
        // Cor de fundo
        if (this.revealed) {
            fill(200); // Cinza claro para células reveladas
        } else {
            fill(100, 200, 100); // Verde para células não reveladas (campo de milho)
        }
        rect(this.x, this.y, cellSize, cellSize);

        if (this.revealed) {
            if (this.hasApple) {
                // Desenha uma maçã vermelha
                fill(255, 0, 0); // Vermelho
                ellipse(this.x + cellSize * 0.5, this.y + cellSize * 0.5, cellSize * 0.6);
                fill(0); // Preto para o cabinho
                rect(this.x + cellSize * 0.5 - 2, this.y + cellSize * 0.2, 4, 10);
            } else {
                // Desenha o número de maçãs vizinhas ou deixa vazio se for 0
                if (this.neighborAppleCount > 0) {
                    textAlign(CENTER, CENTER);
                    textSize(cellSize * 0.6);
                    fill(0); // Cor do texto
                    text(this.neighborAppleCount, this.x + cellSize * 0.5, this.y + cellSize * 0.5);
                }
            }
        } else if (this.flagged) {
            // Desenha uma bandeira (para marcar possíveis maçãs)
            fill(255, 0, 0); // Vermelho da bandeira
            rect(this.x + cellSize * 0.3, this.y + cellSize * 0.2, cellSize * 0.4, cellSize * 0.6);
            line(this.x + cellSize * 0.5, this.y + cellSize * 0.2, this.x + cellSize * 0.5, this.y + cellSize * 0.8);
        }
    }

    // Calcula o número de maçãs vizinhas
    countApples() {
        if (this.hasApple) {
            this.neighborAppleCount = -1; // -1 para indicar que é uma maçã
            return;
        }
        let total = 0;
        for (let i_offset = -1; i_offset <= 1; i_offset++) {
            for (let j_offset = -1; j_offset <= 1; j_offset++) {
                let ni = this.i + i_offset;
                let nj = this.j + j_offset;

                if (ni >= 0 && ni < cols && nj >= 0 && nj < rows) {
                    let neighbor = grid[ni][nj];
                    if (neighbor.hasApple) {
                        total++;
                    }
                }
            }
        }
        this.neighborAppleCount = total;
    }

    // Revela a célula
    reveal() {
        this.revealed = true;
        revealedCount++;
        if (this.hasApple) {
            gameover = true;
            revealAll();
        } else if (this.neighborAppleCount === 0) {
            // Se for 0, revela recursivamente os vizinhos
            this.floodFill();
        }
    }

    // Função Flood Fill para revelar células vazias
    floodFill() {
        for (let i_offset = -1; i_offset <= 1; i_offset++) {
            for (let j_offset = -1; j_offset <= 1; j_offset++) {
                let ni = this.i + i_offset;
                let nj = this.j + j_offset;

                if (ni >= 0 && ni < cols && nj >= 0 && nj < rows) {
                    let neighbor = grid[ni][nj];
                    if (!neighbor.revealed && !neighbor.hasApple) { // Não revela maçãs
                        neighbor.reveal();
                    }
                }
            }
        }
    }
}

function setup() {
    createCanvas(600, 400); // Ajuste o tamanho do canvas para o jogo
    cols = floor(width / cellSize);
    rows = floor(height / cellSize);
    initializeGame(); // Inicializa o jogo

    // Adiciona o evento de clique para o botão de reset
    let resetButton = select('#resetButton');
    resetButton.mousePressed(initializeGame);
}

function initializeGame() {
    gameover = false;
    revealedCount = 0;
    grid = [];

    // Cria as células do grid
    for (let i = 0; i < cols; i++) {
        grid[i] = [];
        for (let j = 0; j < rows; j++) {
            grid[i][j] = new Cell(i, j);
        }
    }

    // Posiciona as maçãs aleatoriamente
    let options = [];
    for (let i = 0; i < cols; i++) {
        for (let j = 0; j < rows; j++) {
            options.push([i, j]);
        }
    }

    for (let n = 0; n < totalApples; n++) {
        let index = floor(random(options.length));
        let choice = options[index];
        let i = choice[0];
        let j = choice[1];
        options.splice(index, 1); // Remove a opção para não colocar maçã no mesmo lugar
        grid[i][j].hasApple = true;
    }

    // Calcula o número de maçãs vizinhas para cada célula
    for (let i = 0; i < cols; i++) {
        for (let j = 0; j < rows; j++) {
            grid[i][j].countApples();
        }
    }
}

function draw() {
    background(107, 142, 35); // Cor de fundo que lembra um campo verde

    for (let i = 0; i < cols; i++) {
        for (let j = 0; j < rows; j++) {
            grid[i][j].show();
        }
    }

    if (gameover) {
        fill(255, 0, 0, 180);
        rect(0, 0, width, height);
        textAlign(CENTER, CENTER);
        textSize(48);
        fill(255);
        text("GAME OVER! Você pisou numa maçã podre.", width / 2, height / 2);
    } else if (revealedCount === (cols * rows) - totalApples) {
        fill(0, 200, 0, 180);
        rect(0, 0, width, height);
        textAlign(CENTER, CENTER);
        textSize(48);
        fill(255);
        text("PARABÉNS! Você achou todos os milhos!", width / 2, height / 2);
    }
}

function mousePressed() {
    if (gameover || revealedCount === (cols * rows) - totalApples) {
        // Não permite cliques se o jogo acabou
        return false;
    }

    let i = floor(mouseX / cellSize);
    let j = floor(mouseY / cellSize);

    if (i >= 0 && i < cols && j >= 0 && j < rows) {
        if (mouseButton === LEFT) {
            // Revela a célula com o clique esquerdo
            grid[i][j].reveal();
        } else if (mouseButton === RIGHT) {
            // Marca/desmarca a célula com a bandeira (maçã suspeita)
            grid[i][j].flagged = !grid[i][j].flagged;
        }
    }
    return false; // Evita o menu de contexto do botão direito
}

// Função para revelar todas as células (usado no game over)
function revealAll() {
    for (let i = 0; i < cols; i++) {
        for (let j = 0; j < rows; j++) {
            grid[i][j].revealed = true;
        }
    }
}